var product = 8 * 10;


