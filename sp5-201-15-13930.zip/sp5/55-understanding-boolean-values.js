function welcomeToBooleans() {

// Only change code below this line.

return true; // Change this line

// Only change code above this line.
}
