var ourDecimal = 5.7;

// Only change code below this line
var myDecimal=4.3;

