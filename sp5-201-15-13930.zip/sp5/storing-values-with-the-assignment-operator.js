// Setup
var a;
a=7;

// Only change code below this line
