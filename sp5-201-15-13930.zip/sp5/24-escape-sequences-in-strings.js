var myStr= "FirstLine\n\ttab\\SecondLine\nThirdLine"; // Change this line


