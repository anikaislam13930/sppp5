// Example
var ourStr = "I come first. " + "I come second.";

// Only change code below this line

var myStr="This is the start. "+"This is the end."


