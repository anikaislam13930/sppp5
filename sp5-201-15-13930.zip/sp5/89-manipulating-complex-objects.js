var myMusic = [
  {
    "artist": "Billy Joel",
    "title": "Piano Man",
    "release_year": 1973,
    "formats": [ 
      "CD",
      "8T",
      "LP"
    ],
    "gold": true
  },
  {
    "artist": "Test Case",
    "title": "Test Man",
    "release_year": 2019,
    "formats": [ 
      "Netflix",
      "8T",
      "LP"
    ],

  }
  // Add record here
];

