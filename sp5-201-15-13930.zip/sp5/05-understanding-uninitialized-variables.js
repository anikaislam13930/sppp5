// Initialize these three variables
var a;
var b;
var c;
a=5;
b=10;
c="I am a";
// Do not change code below this line

a = a + 1;
b = b + 5;
c = c + " String!";

