// Setup
var myArray = [];
var i = 10;

// Only change code below this line.

do{
  myArray.push(i);
  i++;
}while (i < 11) ;

