// Example
var ourDog = {
  "name": "Camper",
  "legs": 4,
  "tails": 1,
  "friends": ["everything!"]
};

// Only change code below this line.

var myDog = {
  "name": "puffy",
  "legs": 4,
  "tails": 1,
  "friends": ["watson", "kat"]
  
  
};
