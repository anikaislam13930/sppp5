// Example
function minusSeven(num) {
  return num - 7;
}

// Only change code below this line

function timesFive(num) {
  return num*5;
}

console.log(timesFive(10));
