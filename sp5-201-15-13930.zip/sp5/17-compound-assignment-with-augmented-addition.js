var a = 3;
var b = 17;
var c = 12;

// Only modify code below this line

a += 12;
b += 9 ;
c += 7;

